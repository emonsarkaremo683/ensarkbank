package com.elitetech_inc.ensarkbank.util;

import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class Utils {

    public String generateReference() {
        String uuid = UUID.randomUUID().toString().replace("-", "").toUpperCase();
        return uuid.substring(0, 12);
    }
}
