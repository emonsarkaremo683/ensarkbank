package com.elitetech_inc.ensarkbank.branch_management.branch.repository;


import com.elitetech_inc.ensarkbank.branch_management.branch.entity.Branch;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface BranchRepository extends JpaRepository<Branch, Long> {
    Optional<Branch> findByBranchCode(String branchCode);
    Optional<Branch> findByEmail(String email);
}
