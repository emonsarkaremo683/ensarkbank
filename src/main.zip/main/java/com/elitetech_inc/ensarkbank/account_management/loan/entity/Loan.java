package com.elitetech_inc.ensarkbank.account_management.loan.entity;

import com.elitetech_inc.ensarkbank.account_management.account.entity.Account;
import com.elitetech_inc.ensarkbank.common.entity.BaseEntity;
import com.elitetech_inc.ensarkbank.common.enums.LoanStatus;
import com.elitetech_inc.ensarkbank.common.enums.LoanType;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDate;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@Table(name = "loan_applications")
public class Loan extends BaseEntity {

        @Column(nullable = false, unique = true)
        private String loanNumber;

        @Enumerated(EnumType.STRING)
        @Column(nullable = false)
        private LoanType loanType;

        @Enumerated(EnumType.STRING)
        @Column(nullable = false)
        private LoanStatus status;

        @ManyToOne(fetch = FetchType.LAZY)
        @JoinColumn(name = "account_id", nullable = false)
        private Account account;

        @Column(nullable = false, precision = 18, scale = 2)
        private BigDecimal loanAmount;

        @Column(nullable = false, precision = 5, scale = 2)
        private BigDecimal interestRate;

        @Column(nullable = false)
        private Integer tenureMonths;

        @Column(nullable = false)
        private LocalDate disbursementDate;

        @Column(nullable = false)
        private LocalDate maturityDate;

        @Column(nullable = false, precision = 18, scale = 2)
        private BigDecimal totalPayableAmount;

        @Column(nullable = false, precision = 18, scale = 2)
        private BigDecimal outstandingBalance;

        @Column(nullable = false, precision = 18, scale = 2)
        private BigDecimal emiAmount;

        @Column(length = 500)
        private String purpose;

        @Column(length = 1000)
        private String remarks;

}
