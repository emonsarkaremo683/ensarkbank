package com.ensark.elitebank.auth.dto.request;

import lombok.Data;

@Data
public class ForgetPasswordRequest {
    private String email;
}
